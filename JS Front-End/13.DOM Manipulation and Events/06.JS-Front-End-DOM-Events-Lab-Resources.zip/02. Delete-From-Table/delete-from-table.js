function deleteByEmail() {
    //TODO
}
