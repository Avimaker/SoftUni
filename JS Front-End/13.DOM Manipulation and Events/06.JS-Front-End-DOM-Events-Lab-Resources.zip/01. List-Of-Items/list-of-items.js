function addItem() {
    //TODO
}
