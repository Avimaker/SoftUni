function attachGradientEvents() {
    //TODO
}
