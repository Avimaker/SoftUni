function addItem() {
    // TODO
}
