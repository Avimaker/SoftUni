﻿
namespace FoodShortage.Models.Interfaces
{
	public interface IId
	{
		public string Id { get; }
	}
}

