﻿
namespace FoodShortage.Models.Interfaces
{
	public interface IName
	{
        public string Name { get; }
    }
}

