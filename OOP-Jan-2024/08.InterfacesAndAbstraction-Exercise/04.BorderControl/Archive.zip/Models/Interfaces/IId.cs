﻿using System;
namespace BorderControl.Models.Interfaces
{
	public interface IId
	{
		string Id { get; }
	}
}

