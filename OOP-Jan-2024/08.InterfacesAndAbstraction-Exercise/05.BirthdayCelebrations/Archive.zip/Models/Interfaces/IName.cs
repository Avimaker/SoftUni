﻿using System;
namespace BirthdayCelebrations.Models.Interfaces
{
	public interface IName
	{
        public string Name { get; }
    }
}

