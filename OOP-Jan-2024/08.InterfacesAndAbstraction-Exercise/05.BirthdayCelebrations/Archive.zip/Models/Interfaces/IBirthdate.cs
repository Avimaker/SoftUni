﻿using System;
namespace BirthdayCelebrations.Models.Interfaces
{
	public interface IBirthdate
	{
		public string Birthdate { get; }
	}

}

