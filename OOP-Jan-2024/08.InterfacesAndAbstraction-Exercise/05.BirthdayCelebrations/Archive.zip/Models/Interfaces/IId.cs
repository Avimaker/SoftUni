﻿using System;
namespace BirthdayCelebrations.Models.Interfaces
{
	public interface IId
	{
		public string Id { get; }
	}
}

