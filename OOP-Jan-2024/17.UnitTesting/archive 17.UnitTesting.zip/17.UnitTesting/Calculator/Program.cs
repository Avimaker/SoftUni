﻿using System.ComponentModel;

namespace Calculator;
class Program
{
    static void Main(string[] args)
    {
        Calculator calculator = new Calculator();

        calculator.Add(5, 6);


    }
}

