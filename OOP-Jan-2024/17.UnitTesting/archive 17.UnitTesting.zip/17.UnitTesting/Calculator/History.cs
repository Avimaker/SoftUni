﻿using System;
namespace Calculator
{
	public class History
	{
		public List<string> Inputs { get; set; }
		 
	}
}

