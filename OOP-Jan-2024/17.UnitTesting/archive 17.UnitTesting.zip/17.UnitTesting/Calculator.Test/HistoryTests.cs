﻿using System;
namespace Calculator.Test
{
	public class HistoryTests
	{

		[Test]
		public void TestHistory()
		{

		}

	}
}

