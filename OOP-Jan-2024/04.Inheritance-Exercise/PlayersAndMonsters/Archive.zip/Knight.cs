﻿
namespace PlayersAndMonsters
{
	public abstract class Knight : Hero
	{
		public Knight(string username, int level) : base(username, level)
        {
		}
	}
}

