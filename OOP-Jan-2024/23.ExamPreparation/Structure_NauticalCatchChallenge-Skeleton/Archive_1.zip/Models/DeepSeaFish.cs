﻿using System;
namespace NauticalCatchChallenge.Models
{
	public class DeepSeaFish : Fish
    {
        public DeepSeaFish(string name, double points, int timeToCatch) : base(name, points, 180)
        {
        }
    }
}

