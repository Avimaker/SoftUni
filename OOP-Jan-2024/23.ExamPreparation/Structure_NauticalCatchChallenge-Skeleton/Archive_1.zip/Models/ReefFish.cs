﻿using System;
namespace NauticalCatchChallenge.Models
{
    public class ReefFish : Fish
    {
        public ReefFish(string name, double points, int timeToCatch) : base(name, points, 30)
        {
        }
    }
}

