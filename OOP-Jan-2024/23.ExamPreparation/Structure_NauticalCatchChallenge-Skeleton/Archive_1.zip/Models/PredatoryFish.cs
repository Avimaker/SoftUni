﻿using System;
namespace NauticalCatchChallenge.Models
{
	public class PredatoryFish : Fish
    {
        public PredatoryFish(string name, double points, int timeToCatch) : base(name, points, 60)
        {
        }
    }
}

