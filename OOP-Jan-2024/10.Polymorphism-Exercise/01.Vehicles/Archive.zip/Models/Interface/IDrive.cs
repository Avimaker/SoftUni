﻿using System;
namespace Vehicles.Models.Interface;

public interface IDrive
{
    public string Drive(double distance);
}

