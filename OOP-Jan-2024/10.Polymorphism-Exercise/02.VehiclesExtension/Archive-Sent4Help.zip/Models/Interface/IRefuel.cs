﻿using System;
namespace Vehicles.Models.Interface;

public interface IRefuel
{
    public void Refuel(double liters);
}

