﻿using System;
using InfluencerManagerApp.Core.Contracts;
using InfluencerManagerApp.Models;
using InfluencerManagerApp.Models.Contracts;
using InfluencerManagerApp.Repositories;
using InfluencerManagerApp.Repositories.Contracts;

namespace InfluencerManagerApp.Core
{
    public class Controller : IController
    {

        private IRepository<IInfluencer> influencers;
        private IRepository<ICampaign> campaigns;

        public Controller()
        {
            influencers = new InfluencerRepository();
            campaigns = new CampaignRepository();
        }

        //ok
        public string RegisterInfluencer(string typeName, string username, int followers)
        {
            if (typeName != nameof(BusinessInfluencer)
                && typeName != nameof(FashionInfluencer)
                && typeName != nameof(BloggerInfluencer))
            {
                return $"{typeName} has not passed validation.";
            }

            IInfluencer existInfluencer = influencers.FindByName(username);

            if (existInfluencer != null)
            {
                return $"{username} is already registered in InfluencerRepository.";//todo check 
            }

            IInfluencer newInfluencer = null;

            if (typeName == nameof(BusinessInfluencer))
            {
                newInfluencer = new BusinessInfluencer(username, followers);
            }

            else if (typeName == nameof(FashionInfluencer))
            {
                newInfluencer = new FashionInfluencer(username, followers);
            }

            else if (typeName == nameof(BloggerInfluencer))
            {
                newInfluencer = new BloggerInfluencer(username, followers);
            }

            influencers.AddModel(newInfluencer);

            return $"{username} registered successfully to the application.";

        }

        //working...
        public string BeginCampaign(string typeName, string brand)
        {
            if (typeName != nameof(ProductCampaign)
                && typeName != nameof(ServiceCampaign))
            {
                return $"{typeName} is not a valid campaign in the application.";
            }

            ICampaign existexistingCampaign = campaigns.FindByName(brand);

            if (existexistingCampaign != null)
            {
                return $"{brand} campaign cannot be duplicated.";
            }


            ICampaign newCampaign = null;

            if (typeName == nameof(ProductCampaign))
            {
                newCampaign = new ProductCampaign(brand);
            }

            if (typeName == nameof(ServiceCampaign))
            {
                newCampaign = new ServiceCampaign(brand);
            }

            campaigns.AddModel(newCampaign);

            return $"{brand} started a {typeName}.";
        }


        public string ApplicationReport()
        {
            throw new NotImplementedException();
        }

        public string AttractInfluencer(string brand, string username)
        {
            throw new NotImplementedException();
        }

      

        public string CloseCampaign(string brand)
        {
            throw new NotImplementedException();
        }

        public string ConcludeAppContract(string username)
        {
            throw new NotImplementedException();
        }

        public string FundCampaign(string brand, double amount)
        {
            throw new NotImplementedException();
        }

        
    }
}

