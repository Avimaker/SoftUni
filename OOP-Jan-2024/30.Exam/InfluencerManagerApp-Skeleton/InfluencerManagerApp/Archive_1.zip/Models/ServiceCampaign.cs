﻿using System;
namespace InfluencerManagerApp.Models
{
	public class ServiceCampaign : Campaign
	{
		
	}
}

