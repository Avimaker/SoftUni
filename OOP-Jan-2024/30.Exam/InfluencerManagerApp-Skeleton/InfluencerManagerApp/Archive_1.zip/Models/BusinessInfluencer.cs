﻿using System;
namespace InfluencerManagerApp.Models
{
	public class BusinessInfluencer : Influencer
	{
	
	}
}

