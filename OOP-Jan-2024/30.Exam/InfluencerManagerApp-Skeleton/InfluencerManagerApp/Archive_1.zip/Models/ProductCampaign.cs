﻿using System;
namespace InfluencerManagerApp.Models
{
	public class ProductCampaign : Campaign
	{
		
	}
}

