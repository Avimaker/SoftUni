﻿using System;
using InfluencerManagerApp.Models.Contracts;
using InfluencerManagerApp.Repositories.Contracts;

namespace InfluencerManagerApp.Repositories
{
    public class InfluencerRepository : IRepository<IInfluencer>
    {
        public IReadOnlyCollection<IInfluencer> Models => throw new NotImplementedException();

        public void AddModel(IInfluencer model)
        {
            throw new NotImplementedException();
        }

        public IInfluencer FindByName(string name)
        {
            throw new NotImplementedException();
        }

        public bool RemoveModel(IInfluencer model)
        {
            throw new NotImplementedException();
        }
    }
}

