﻿using System;
namespace EDriveRent.Models
{
	public class PassengerCar : Vehicle
	{
		
	}
}

