﻿using System;
namespace EDriveRent.Models
{
	public class CargoVan : Vehicle
	{
		
	}
}

