﻿using System;
using System.Collections.Generic;
using System.Linq;
using EDriveRent.Core.Contracts;
using EDriveRent.Models;
using EDriveRent.Models.Contracts;
using EDriveRent.Repositories;
using EDriveRent.Repositories.Contracts;
using EDriveRent.Utilities.Messages;

namespace EDriveRent.Core
{
    public class Controller : IController
    {
        private IRepository<IUser> users;
        private IRepository<IVehicle> vehicles;
        private IRepository<IRoute> routes;

        public Controller()
        {
            users = new UserRepository();
            vehicles = new VehicleRepository();
            routes = new RouteRepository();
        }

        public string RegisterUser(string firstName, string lastName, string drivingLicenseNumber)
        {
            //търсим в списъка с настоящи
            IUser user = users.FindById(drivingLicenseNumber);
            //създаваме нов юзър който да проверим и да добавим 
            User newUser = new User(firstName, lastName, drivingLicenseNumber);

            if (user != null)// ако метода не върне null значи има такъв и показваме грешка
            {
                return $"{drivingLicenseNumber} is already registered in our platform.";
            }

            users.AddModel(newUser);

            return $"{firstName} {lastName} is registered successfully with DLN-{drivingLicenseNumber}";
        }

        public string UploadVehicle(string vehicleType, string brand, string model, string licensePlateNumber)
        {
            if (vehicleType != nameof(PassengerCar) && vehicleType != nameof(CargoVan))
            {
                return $"{vehicleType} is not accessible in our platform.";
            }

            IVehicle existVehicle = vehicles.FindById(licensePlateNumber);

            if (existVehicle != null) //проверката трябва да е така
            {
                return $"{licensePlateNumber} belongs to another vehicle.";
            }

            IVehicle newVehicle = null;

            if (vehicleType == nameof(PassengerCar))
            {
                newVehicle = new PassengerCar(brand, model, licensePlateNumber);
            }
            else
            {
                newVehicle = new CargoVan(brand, model, licensePlateNumber);
            }

            vehicles.AddModel(newVehicle);

            return $"{brand} {model} is uploaded successfully with LPN-{licensePlateNumber}";
        }


        public string AllowRoute(string startPoint, string endPoint, double length)
        {
            int routeId = routes.GetAll().Count + 1;

            IRoute existingRoutes = routes.GetAll().FirstOrDefault(r => r.StartPoint == startPoint && r.EndPoint == endPoint);

            if (existingRoutes != null)//ако има път влизаме
            {
                if (existingRoutes.Length == length)//ако има с търсената дължина
                {
                    return string.Format(OutputMessages.RouteExisting, startPoint, endPoint, length);
                }
                else if (existingRoutes.Length < length)//ако има с по-къса дължина
                {
                    return string.Format(OutputMessages.RouteIsTooLong, startPoint, endPoint, length);
                }
                else if (existingRoutes.Length > length)//ако има с по-голяма дължина
                {
                    existingRoutes.LockRoute();
                }
            }

            IRoute newRoute = new Route(startPoint, endPoint, length, routeId);

            routes.AddModel(newRoute);

            return $"{startPoint}/{endPoint} - {length} km is unlocked in our platform.";
        }



        public string MakeTrip(string drivingLicenseNumber, string licensePlateNumber, string routeId, bool isAccidentHappened)
        {
            throw new NotImplementedException();
        }



        public string RepairVehicles(int count)
        {
            throw new NotImplementedException();
        }



        public string UsersReport()
        {
            throw new NotImplementedException();
        }
    }
}

