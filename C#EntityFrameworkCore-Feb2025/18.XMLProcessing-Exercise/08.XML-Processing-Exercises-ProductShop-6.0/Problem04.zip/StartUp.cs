﻿using System.ComponentModel.DataAnnotations;
using System.Linq;
using CarDealer.Utilities;
using Microsoft.EntityFrameworkCore;
using ProductShop.Data;
using ProductShop.DTOs.Import;
using ProductShop.Models;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main()
        {
            using ProductShopContext dbContext = new ProductShopContext();
            //dbContext.Database.Migrate();
            //Console.WriteLine("Db Migrated Succesfuly!");

            ////Query 1. Import Users
            //const string xmlFilePath = "../../../Datasets/users.xml";
            //string inputXml = File.ReadAllText(xmlFilePath);
            //string result = ImportUsers(dbContext, inputXml);
            //Console.WriteLine(result);

            ////Query 2. Import Products
            //const string xmlFilePath = "../../../Datasets/products.xml";
            //string inputXml = File.ReadAllText(xmlFilePath);
            //string result = ImportProducts(dbContext, inputXml);
            //Console.WriteLine(result);

            ////Query 3.Import Categories
            //const string xmlFilePath = "../../../Datasets/categories.xml";
            //string inputXml = File.ReadAllText(xmlFilePath);
            //string result = ImportCategories(dbContext, inputXml);
            //Console.WriteLine(result);

            //Query 4. Import Categories and Products
            const string xmlFilePath = "../../../Datasets/categories-products.xml";
            string inputXml = File.ReadAllText(xmlFilePath);
            string result = ImportCategoryProducts(dbContext, inputXml);
            Console.WriteLine(result);

        }

        //Query 1. Import Users
        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            //1st create empty string
            string result = string.Empty;

            //use dto that already create plus root name + XmlHelper
            ImportUserDto[]? importUserDtos = XmlHelper
                .Deserialize<ImportUserDto[]>(inputXml, "Users");

            if (importUserDtos != null) //if no data - skip
            {
                //ако има данни правим колекция
                ICollection<User> validUsers = new List<User>();

                //завъртаме циъл
                foreach (ImportUserDto importUserDto in importUserDtos)
                {
                    //first check if the dto isValid
                    if (!IsValid(importUserDto))
                    {
                        continue;
                    }

                    //if it is valid we have to check parse props from dto
                    bool isAgeValid = int.TryParse(importUserDto.Age, out int age);

                    //check if some of them are invalid we have to skip
                    if (!isAgeValid)
                    {
                        continue;
                    }

                    // ако сме минали всички проверки успешно трябва да направим инстанция на частта която ще съдържа валидната информация
                    User user = new User()
                    {
                        FirstName = importUserDto.FirstName,
                        LastName = importUserDto.LastName,
                        Age = age
                    };

                    //добавяме я към колекцията от валидните части
                    validUsers.Add(user);
                }

                //след форича в контекста през диби сета за частите трябва да добавя новите валидни части чрез ад реиндж.
                context.Users.AddRange(validUsers);

                // тригерирам запазване на промени
                context.SaveChanges();

                //ако всичко мине ок запазваме в резултат
                result = $"Successfully imported {validUsers.Count}";

            }

            return result;
        }

        //Query 2. Import Products
        public static string ImportProducts(ProductShopContext context, string inputXml)
        {

            string result = string.Empty;

            ImportProductDto[]? productDtos = XmlHelper
                .Deserialize<ImportProductDto[]>(inputXml, "Products");

            if (productDtos != null)
            {

                ICollection<Product> validProducts = new List<Product>();

                foreach (ImportProductDto productDto in productDtos)
                {
                    ICollection<int> dbUsers = context
                    .Users
                    .Select(u => u.Id)
                    .ToArray();

                    if (!IsValid(productDto))
                    {
                        continue;
                    }

                    bool isPriceValid = decimal.TryParse(productDto.Price, out decimal price);
                    bool isSellerIdValid = int.TryParse(productDto.SellerId, out int sellerId);


                    if ((!isPriceValid) || (!isSellerIdValid))
                    {
                        continue;
                    }

                    int? buyerId = null;
                    if (productDto.BuyerId != null)
                    {
                        bool isBuyerIdValid = int
                            .TryParse(productDto.BuyerId, out int parsedBuyerId);
                        if (!isBuyerIdValid)
                        {
                            continue;
                        }

                        buyerId = parsedBuyerId;
                    }


                    Product product = new Product()
                    {
                        Name = productDto.Name,
                        Price = price,
                        SellerId = sellerId,
                        BuyerId = buyerId
                    };

                    validProducts.Add(product);
                }

                context.Products.AddRange(validProducts);
                context.SaveChanges();

                result = $"Successfully imported {validProducts.Count}";
            }

            return result;
        }

        //Query 3.Import Categories
        public static string ImportCategories(ProductShopContext context, string inputXml)
        {
            string result = string.Empty;

            ImportCategoriesDto[]? categoriesDtos = XmlHelper
                .Deserialize<ImportCategoriesDto[]>(inputXml, "Categories");

            if (categoriesDtos != null)
            {
                ICollection<Category> validCategories = new List<Category>();

                foreach (ImportCategoriesDto categoriesDto in categoriesDtos)
                {
                    if (!IsValid(categoriesDto))
                    {
                        continue;
                    }

                    Category category = new Category()
                    {
                        Name = categoriesDto.Name
                    };

                    validCategories.Add(category);
                }

                context.Categories.AddRange(validCategories);
                context.SaveChanges();

                result = $"Successfully imported {validCategories.Count}";
            }

            return result;
        }

        //Query 4. Import Categories and Products
        public static string ImportCategoryProducts(ProductShopContext context, string inputXml)
        {
            string result = string.Empty;

            ImportCategoryProductsDto[]? categoriesDtos = XmlHelper
                .Deserialize<ImportCategoryProductsDto[]>(inputXml, "CategoryProducts");

            if (categoriesDtos != null)
            {
                ICollection<CategoryProduct> validCategoryProducts = new List<CategoryProduct>();

                foreach (ImportCategoryProductsDto categoriesDto in categoriesDtos)
                {
                    if (!IsValid(categoriesDto))
                    {
                        continue;
                    }

                    bool isCategoryIdValid = int.TryParse(categoriesDto.CategoryId, out int categoryId);
                    bool isProductIdValid = int.TryParse(categoriesDto.ProductId, out int productId);

                    if ((!isCategoryIdValid) || (!isProductIdValid))
                    {
                        continue;
                    }

                    CategoryProduct categoryProduct = new CategoryProduct()
                    {
                        CategoryId = categoryId,
                        ProductId = productId
                    };

                    validCategoryProducts.Add(categoryProduct);
                }

                context.CategoryProducts.AddRange(validCategoryProducts);
                context.SaveChanges();

                result = $"Successfully imported {validCategoryProducts.Count}";
            }

            return result;
        }


        // helper method IsValid
        public static bool IsValid(object dto)
        {
            var validateContext = new ValidationContext(dto);
            var validationResults = new List<ValidationResult>();

            bool isValid = Validator
                .TryValidateObject(dto, validateContext, validationResults, true);

            return isValid;
        }
    }
}