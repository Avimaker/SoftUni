﻿using System.ComponentModel.DataAnnotations;
using CarDealer.Utilities;
using Microsoft.EntityFrameworkCore;
using ProductShop.Data;
using ProductShop.DTOs.Import;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main()
        {
            using ProductShopContext dbContext = new ProductShopContext();
            dbContext.Database.Migrate();
            //Console.WriteLine("Db Migrated Succesfuly!");

            //Query 1. Import Users
            const string xmlFilePath = "../../../Datasets/users.xml";
            string inputXml = File.ReadAllText(xmlFilePath);
            string result = ImportUsers(dbContext, inputXml);
            Console.WriteLine(result);
        }

        //Query 1. Import Users
        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            string result = string.Empty;

            //use dto that already create plus root name + XmlHelper
            ImportUserDto[]? importUserDtos = XmlHelper
                .Deserialize<ImportUserDto[]>(inputXml, "Users");

            if (importUserDtos != null)
            {
                ICollection<User> validUsers = new List<User>();

                foreach (ImportUserDto importUserDto in importUserDtos)
                {
                    if (!IsValid(importUserDto))
                    {
                        continue;
                    }

                    //int? age = null;
                    //if (importUserDto.Age != null)
                    //{
                    //    int parsedAge = 0;
                    //    bool isAgeValid = int.TryParse(importUserDto.Age, out parsedAge);
                    //    if (!isAgeValid)
                    //    {
                    //        continue;
                    //    }

                    //    age = parsedAge;
                    //}

                    bool isAgeValid = int.TryParse(importUserDto.Age, out int age);
                    if (!isAgeValid)
                    {
                        continue;
                    }

                    User user = new User()
                    {
                        FirstName = importUserDto.FirstName,
                        LastName = importUserDto.LastName,
                        Age = age
                    };

                    validUsers.Add(user);
                }

                context.Users.AddRange(validUsers);
                context.SaveChanges();

                result = $"Successfully imported {validUsers.Count}";

            }

            return result;
        }


        // helper method IsValid
        public static bool IsValid(object dto)
        {
            var validateContext = new ValidationContext(dto);
            var validationResults = new List<ValidationResult>();

            bool isValid = Validator
                .TryValidateObject(dto, validateContext, validationResults, true);

            return isValid;
        }
    }
}