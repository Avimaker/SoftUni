﻿using System.ComponentModel.DataAnnotations;
using CarDealer.Data;
using CarDealer.DTOs.Import;
using CarDealer.Models;
using CarDealer.Utilities;
using Microsoft.EntityFrameworkCore;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            using CarDealerContext dbContext = new CarDealerContext();
            dbContext.Database.Migrate();
            Console.WriteLine("db migrated to the last version successfuly!");

            ////Query 9. Import Suppliers
            //const string xmlFilePath = "../../../Datasets/suppliers.xml";
            //string inputXml = File.ReadAllText(xmlFilePath);
            //string result = ImportSuppliers(dbContext, inputXml);
            //Console.WriteLine(result);

            //Query 10. Import Parts
            const string xmlFilePath = "../../../Datasets/parts.xml";
            string inputXml = File.ReadAllText(xmlFilePath);
            string result = ImportParts(dbContext, inputXml);
            Console.WriteLine(result);


        }

        
        //Query 9. Import Suppliers
        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            string result = string.Empty;

            //use dto that already create plus root name + XmlHelper
            ImportSupplierDto[]? supplierDtos = XmlHelper
                .Deserialize<ImportSupplierDto[]>(inputXml, "Suppliers");

            if (supplierDtos != null)
            {
                ICollection<Supplier> validSuppliers = new List<Supplier>();
                foreach (ImportSupplierDto supplierDto in supplierDtos)
                {
                    if (!IsValid(supplierDto))
                    {
                        continue;
                    }

                    bool isImporterValid = bool
                        .TryParse(supplierDto.isImporter, out bool isImporter);

                    if (!isImporterValid)
                    {
                        continue;
                    }

                    Supplier supplier = new Supplier()
                    {
                        Name = supplierDto.name,
                        IsImporter = isImporter
                    };

                    validSuppliers.Add(supplier);
                }

                context.Suppliers.AddRange(validSuppliers);
                context.SaveChanges();

                result = $"Successfully imported {validSuppliers.Count}";
            }

            return result;
        }


        //Query 10. Import Parts
        public static string ImportParts(CarDealerContext context, string inputXml)
        {
            string result = string.Empty;

            //use dto that already create plus root name + XmlHelper
            ImportPartDto[]? partDtos = XmlHelper
                .Deserialize<ImportPartDto[]>(inputXml, "Parts");

            if (partDtos != null) //use for foreach
            {
                //If the supplierId doesn't exist, skip the record.
                ICollection<int> dbSupplierIds = context
                    .Suppliers
                    .Select(s => s.Id)
                    .ToArray();

                ICollection<Part> validParts = new List<Part>();

                foreach (ImportPartDto partDto in partDtos)
                {
                    //first check if the dto isValid
                    if (!IsValid(partDto))
                    {
                        continue;
                    }

                    //if it is valid we have to check parse props from dto
                    bool isPriceValid = decimal
                        .TryParse(partDto.Price, out decimal price);
                    bool isQuantityValid = int
                        .TryParse(partDto.Quantity, out int quantity);
                    bool isSupplierValid = int
                        .TryParse(partDto.SupplierId, out int supplierId);
                    //check if some of them are invalid we have to skip
                    if ((!isPriceValid) || (!isQuantityValid) || (!isSupplierValid))
                    {
                        //invalid values for price, quantity or supplier
                        continue;
                    }

                    // if they are valid and are parsed we have to check is there valid supplier in db to add to him
                    if (!dbSupplierIds.Contains(supplierId))
                    {
                        // Non-existing supplierId which would violate teh FK Contraint
                        continue;
                    }

                    // ако сме минали всички проверки успешно трябва да направим инстанция на частта която ще съдържа валидната информация
                    Part part = new Part()
                    {
                        Name = partDto.Name,
                        Price = price,
                        Quantity = quantity,
                        SupplierId = supplierId
                    };

                    //добавяме я към колекцията от валидните части
                    validParts.Add(part);
                }

                //след форича в контекста през диби сета за частите трябва да добавя новите валидни части чрез ад реиндж.
                context.Parts.AddRange(validParts);

                // тригерирам запазване на промени
                context.SaveChanges();

                //ако всичко мине ок запазваме в резултат
                result = $"Successfully imported {validParts.Count}";

            }

            return result;
        }



        // helper method IsValid
        public static bool IsValid(object dto)
        {
            var validateContext = new ValidationContext(dto);
            var validationResults = new List<ValidationResult>();

            bool isValid = Validator
                .TryValidateObject(dto, validateContext, validationResults, true);

            return isValid;
        }
    }
}