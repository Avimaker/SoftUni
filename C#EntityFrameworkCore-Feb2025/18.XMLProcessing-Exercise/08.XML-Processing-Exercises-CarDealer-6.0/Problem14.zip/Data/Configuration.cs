﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=localhost,1433; Database=CraDealerXML; User Id=SA; Password=SoftUni2025; TrustServerCertificate=True;";
    }
}
