﻿namespace TravelAgency.Data.Models.Enums
{
    public enum Language
    {
        English = 1,
        German,
        French,
        Spanish,
        Russian
    }
}

