﻿using System;
namespace TravelAgency.DataProcessor.ImportDtos
{
    public class BookingDto
    {
        public string BookingDate { get; set; }
        public string CustomerName { get; set; }
        public string TourPackageName { get; set; }
    }
}

