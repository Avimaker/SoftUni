﻿using System.ComponentModel.DataAnnotations;
using System.IO;
using CarDealer.Data;
using CarDealer.DTOs.Import;
using CarDealer.Models;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            using CarDealerContext dbContext = new CarDealerContext();
            //dbContext.Database.Migrate();
            //Console.WriteLine("Database migrated successful");

            //// Problem 09
            //string jsonString = File.ReadAllText("../../../Datasets/suppliers.json");
            //string result = ImportSuppliers(dbContext, jsonString);
            //Console.WriteLine(result);

            // Problem 10
            string jsonString = File.ReadAllText("../../../Datasets/parts.json");
            string result = ImportParts(dbContext, jsonString);
            Console.WriteLine(result);

        }

        ////Problem 09
        //public static string ImportSuppliersDS(CarDealerContext context, string inputJson)
        //{
        //    var suppliers = JsonConvert.DeserializeObject<List<Supplier>>(inputJson);
        //    context.Suppliers.AddRange(suppliers);
        //    context.SaveChanges();
        //    return $"Successfully imported {suppliers.Count}.";
        //}

        //Problem 09 ET
        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            string result = string.Empty;

            ImportSuppliersDto[]? importSuppliersDtos = JsonConvert
                .DeserializeObject<ImportSuppliersDto[]>(inputJson);

            if (importSuppliersDtos != null)
            {
                ICollection<Supplier> validSuppliers = new List<Supplier>();

                foreach (ImportSuppliersDto importSuppliersDto in importSuppliersDtos)
                {
                    if (!IsValid(importSuppliersDto))
                    {
                        continue;
                    }

                    Supplier supplier = new Supplier()
                    {
                        Name = importSuppliersDto.Name,
                        IsImporter = importSuppliersDto.IsImporter
                    };

                    validSuppliers.Add(supplier);
                }

                context.Suppliers.AddRange(validSuppliers);
                context.SaveChanges();

                result = $"Successfully imported {validSuppliers.Count}.";
            }

            return result;
        }


        // Problem 10

        // Problem 10 ET
        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            string result = string.Empty;

            ImportPartsDto[]? importPartsDtos = JsonConvert
                .DeserializeObject<ImportPartsDto[]>(inputJson) ?? new ImportPartsDto[0];

            if (importPartsDtos != null)
            {
                ICollection<Part> validParts = new List<Part>();

                foreach (ImportPartsDto importPartsDto in importPartsDtos)
                {

                    if (!IsValid(importPartsDto))
                    {
                        continue;
                    }

                    bool isPriceValid = decimal
                        .TryParse(importPartsDto.Price, out decimal price);
                    bool isQuantityValid = int
                        .TryParse(importPartsDto.Quantity, out int quantity);
                    bool isSupplierIdValid = int
                        .TryParse(importPartsDto.SupplierId, out int supplierId);

                    if ((!isPriceValid) || (!isQuantityValid) || (!isSupplierIdValid))
                    {
                        continue;
                    }

                    // Проверка дали доставчикът съществува
                    if (!context.Suppliers.Any(s => s.Id == supplierId))
                    {
                        continue;
                    }


                    Part part = new Part()
                    {
                        Name = importPartsDto.Name,
                        Price = price,
                        Quantity = quantity,
                        SupplierId = supplierId
                    };

                    validParts.Add(part);
                }
                context.Parts.AddRange(validParts);
                context.SaveChanges();

                result = $"Successfully imported {validParts.Count}.";
            }

            return result;
        }




        // helper method IsValid
        public static bool IsValid(object dto)
        {
            var validateContext = new ValidationContext(dto);
            var validationResults = new List<ValidationResult>();

            bool isValid = Validator
                .TryValidateObject(dto, validateContext, validationResults, true);

            return isValid;
        }

    }
}