﻿using System.ComponentModel.DataAnnotations;
using CarDealer.Data;
using CarDealer.DTOs.Import;
using CarDealer.Models;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            using CarDealerContext dbContext = new CarDealerContext();
            //dbContext.Database.Migrate();
            //Console.WriteLine("Database migrated successful");

            // Problem 09
            string jsonString = File.ReadAllText("../../../Datasets/suppliers.json");
            string result = ImportSuppliers(dbContext, jsonString);
            Console.WriteLine(result);


        }

        ////Problem 09
        //public static string ImportSuppliersDS(CarDealerContext context, string inputJson)
        //{
        //    var suppliers = JsonConvert.DeserializeObject<List<Supplier>>(inputJson);
        //    context.Suppliers.AddRange(suppliers);
        //    context.SaveChanges();
        //    return $"Successfully imported {suppliers.Count}.";
        //}

        //Problem 09 ET
        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            string result = string.Empty;

            ImportSuppliersDto[]? importSuppliersDtos = JsonConvert
                .DeserializeObject<ImportSuppliersDto[]>(inputJson);

            if (importSuppliersDtos != null)
            {
                ICollection<Supplier> validSuppliers = new List<Supplier>();

                foreach (ImportSuppliersDto importSuppliersDto in importSuppliersDtos)
                {
                    if (!IsValid(importSuppliersDto))
                    {
                        continue;
                    }

                    Supplier supplier = new Supplier()
                    {
                        Name = importSuppliersDto.Name,
                        IsImporter = importSuppliersDto.IsImporter
                    };

                    validSuppliers.Add(supplier);
                }

                context.Suppliers.AddRange(validSuppliers);
                context.SaveChanges();

                result = $"Successfully imported {validSuppliers.Count}.";
            }

            return result;
        }






        // helper method IsValid
        public static bool IsValid(object dto)
        {
            var validateContext = new ValidationContext(dto);
            var validationResults = new List<ValidationResult>();

            bool isValid = Validator
                .TryValidateObject(dto, validateContext, validationResults, true);

            return isValid;
        }

    }
}