﻿using System;
namespace CarDealer.DTOs.Import
{
	public class importSalesDto
	{
        public int CarId { get; set; }

        public int CustomerId { get; set; }

        public int Discount { get; set; }

    }
}

