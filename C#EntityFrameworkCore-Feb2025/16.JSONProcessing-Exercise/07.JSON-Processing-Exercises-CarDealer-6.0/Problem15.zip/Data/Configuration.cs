﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=localhost,1433; Database=CarDealer; User Id=SA; Password=SoftUni2025; TrustServerCertificate=True;";
    }
}
