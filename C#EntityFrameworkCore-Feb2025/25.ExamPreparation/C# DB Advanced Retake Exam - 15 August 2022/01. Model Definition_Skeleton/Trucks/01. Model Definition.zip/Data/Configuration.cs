﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=localhost,1433; Database=TrucksDb2025; User Id=SA; Password=SoftUni2025; TrustServerCertificate=True;";
    }
}