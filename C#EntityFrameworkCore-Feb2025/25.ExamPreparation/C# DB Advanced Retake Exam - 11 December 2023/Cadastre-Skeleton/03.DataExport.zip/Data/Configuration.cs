﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=localhost,1433; Database=CadastreDb2025; User Id=SA; Password=SoftUni2025; TrustServerCertificate=True;";

    }
}
