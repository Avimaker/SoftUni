﻿namespace MusicHub.Data.Configuration
{
    public static class ConectionConfiguration
    {
        public static string ConnectionString =
            @"Server=localhost,1433; Database=MusicHub; User Id=SA; Password=SoftUni2025; TrustServerCertificate=True;";
    }
}
