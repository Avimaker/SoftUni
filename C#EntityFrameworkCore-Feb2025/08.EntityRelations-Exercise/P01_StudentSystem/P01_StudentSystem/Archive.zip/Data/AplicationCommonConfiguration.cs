﻿namespace P01_StudentSystem.Data
{
    public class AplicationCommonConfiguration
    {
        public const string ConnectionString = @"Server=localhost,1433; Database=StudentSystemDb; User Id=SA; Password=SoftUni2025; TrustServerCertificate=True;";

    }
}

