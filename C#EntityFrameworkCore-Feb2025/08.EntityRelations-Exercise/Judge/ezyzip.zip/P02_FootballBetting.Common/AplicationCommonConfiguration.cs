﻿namespace P02_FootballBetting.Common
{
    public class AplicationCommonConfiguration
    {
        public const string ConnectionString = @"Server=localhost,1433; Database=FootballBetting2025Db; User Id=SA; Password=SoftUni2025; TrustServerCertificate=True;";

    }
}

