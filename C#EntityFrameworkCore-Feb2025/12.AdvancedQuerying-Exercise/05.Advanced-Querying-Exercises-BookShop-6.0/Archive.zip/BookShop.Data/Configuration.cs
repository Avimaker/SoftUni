﻿namespace BookShop.Data
{
    internal class Configuration
    {
        //internal static string ConnectionString
        //    => "Server=.;Database=BookShop;Integrated Security=True;";

        internal static string ConnectionString
            => "Server=localhost,1433; Database=BookShopDb; User Id=SA; Password=SoftUni2025; TrustServerCertificate=True;";


        

    }
}
