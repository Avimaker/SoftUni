﻿namespace MyDemoApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MyEntity myEntity = new MyEntity();
            Type myEntityType = typeof(MyEntity);
            Console.WriteLine();
        }
    }
}
