﻿using NetPay.Data;

namespace NetPay.DataProcessor
{
    public class Serializer
    {
        public static string ExportHouseholdsWhichHaveExpensesToPay(NetPayContext context)
        {
            throw new NotImplementedException();
        }

        public static string ExportAllServicesWithSuppliers(NetPayContext context)
        {
            throw new NotImplementedException();
        }
    }
}
