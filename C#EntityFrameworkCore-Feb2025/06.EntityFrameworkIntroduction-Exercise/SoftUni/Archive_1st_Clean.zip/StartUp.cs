﻿namespace SoftUni
{
    using System.Text;
    using SoftUni.Data;

    internal class StartUp
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }

        //// 03 
        //public static string GetEmployeesFullInformation(SoftUniContext context)
        //{
        //    var employees = context
        //        .Employees
        //        .OrderBy(e => e.EmployeeId)
        //        .Select(e => new
        //        {
        //            e.FirstName,
        //            e.LastName,
        //            e.MiddleName,
        //            e.JobTitle,
        //            e.Salary
        //        })
        //        .ToArray();

        //    StringBuilder sb = new StringBuilder();

        //    foreach (var e in employees)
        //    {
        //        sb.AppendLine($"{e.FirstName} {e.LastName} {e.MiddleName} {e.JobTitle} {e.Salary:f2}");
        //    }

        //    sb.ToString().TrimEnd();

        //    Console.WriteLine(sb);
        //}

    }
}





