function solve(s1, s2, s3) {
    console.log(s3 + ' ' + s2 + ' ' + s1);
}