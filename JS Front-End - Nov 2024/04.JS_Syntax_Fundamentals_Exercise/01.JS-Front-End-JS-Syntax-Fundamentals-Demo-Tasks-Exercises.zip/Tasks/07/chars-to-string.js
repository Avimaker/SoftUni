function solve(s1, s2, s3) {
    console.log(s1 + s2 + s3);
}

solve('a','b','c'); // abc
solve('%','2','o'); // %2o
solve('1','5','p');	// 15p
