function solve(num) {
    for (let i = 1; i <= 10; i++) {
        console.log(` ${num} X ${i} = ${num * i} `);
    }
}

solve(5);
solve(2);